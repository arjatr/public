#!/bin/bash  
name="$1" 
pass="$2" 
daysx="$3" 
if [ "$daysx" = "three" ];then 
days="2" 
elif [ "$daysx" = "eight" ];then 
days="4" 
elif [ "$daysx" = "fifteen" ];then 
days="6" 
else 
days="1" 
fi 
ipaddres="$4" 
[[ "$ipaddres" = "three" ]]&& exit 
[[ "$ipaddres" = "eight" ]]&& exit 
[[ "$ipaddres" = "fifteen" ]]&& exit 
uid="$5" 
[[ "$uid" = "" ]]&& exit 
domin=$(cat /etc/inset/dominio) 
limitovp=$(cat /etc/inset/limitovp) 
ipc=$(wget -qO- https://www.dropbox.com/s/vjzg8txm50npglq/Blacklist |grep "$ipaddres" |awk -F : {'print $1'}) 
admin=$(wget -qO- https://www.dropbox.com/s/uk2yw1rxiza2b2t/admins |grep "$ipaddres" |awk -F : {'print $1'}) 
if [ $(tail -n +2 /etc/openvpn/easy-rsa/pki/index.txt | grep "^V" | cut -d '=' -f 2|wc -l) -gt "$limitovp" ]; then 
cat <<EOF > datemp 
<div class="col-12 col-lg-4 mb-2">  
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Oops!</strong> SERVIDOR LLENO. </div>
EOF
cat  datemp;rm -rf datemp 
exit 
fi 
if [ "$ipaddres" = "$ipc" ]; then
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Estas usando IP de FlashSSH usa otra ip para crear</strong> </div>
EOF
cat  datemp;rm -rf datemp
exit 
fi 

if [ "$admin" = "$ipaddres" ];then 
pasg="si" 
clear 
else 
pasg="no" 
touch /etc/inset/dateipdays 
if cat /etc/inset/dateipdays|awk -F : '{print $1}'|grep -w "$ipaddres" > /dev/null; then 
cat <<EOF > datemp  
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Oops!</strong> SOLO UN USUARIO POR DIA. </div>
EOF
cat  datemp;rm -rf datemp 
exit 
fi 
if cat /etc/inset/dateipdays|awk -F : '{print $2}'|grep -w "$uid" > /dev/null; then 
cat <<EOF > datemp 
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Oops!</strong> SOLO UN USUARIO POR DIA. </div>
EOF
cat  datemp;rm -rf datemp 
exit 
fi  
fi 
for us in $(cat /etc/inset/deling);do 
teg=$(echo "$1" |grep -c $us|head -1) 
if [ "$teg" = "1" ]; then 
cat <<EOF > datemp  
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Escribe un nombre normal</strong><br> <b>ELIJE EL QUE GENERA LA PAGINA POR DEFECTO</b> </div>
EOF
cat  datemp;rm -rf datemp 
exit 
fi 
done 

newclient () {
usermod -p $(openssl passwd -1 $2) $1
	# Generates the custom client.ovpn
	rm -rf /etc/openvpn/easy-rsa/pki/reqs/$1.req
	rm -rf /etc/openvpn/easy-rsa/pki/issued/$1.crt
	rm -rf /etc/openvpn/easy-rsa/pki/private/$1.key
	cd /etc/openvpn/easy-rsa/
	./easyrsa build-client-full $1 nopass > /dev/null 2>&1
	cd
	cp /etc/openvpn/client-tcp.txt ~/$1-tcp.ovpn
        cp /etc/openvpn/client-udp.txt ~/$1-udp.ovpn
        cp /etc/openvpn/client-ssl.txt ~/$1-ssl.ovpn
	echo "<ca>" >> ~/$1-tcp.ovpn
        echo "<ca>" >> ~/$1-udp.ovpn
        echo "<ca>" >> ~/$1-ssl.ovpn
	cat /etc/openvpn/easy-rsa/pki/ca.crt >> ~/$1-tcp.ovpn
        cat /etc/openvpn/easy-rsa/pki/ca.crt >> ~/$1-udp.ovpn
        cat /etc/openvpn/easy-rsa/pki/ca.crt >> ~/$1-ssl.ovpn
	echo "</ca>" >> ~/$1-tcp.ovpn
        echo "</ca>" >> ~/$1-udp.ovpn
        echo "</ca>" >> ~/$1-ssl.ovpn
	echo "<cert>" >> ~/$1-tcp.ovpn
	echo "<cert>" >> ~/$1-udp.ovpn
	echo "<cert>" >> ~/$1-ssl.ovpn
	cat /etc/openvpn/easy-rsa/pki/issued/$1.crt >> ~/$1-tcp.ovpn
	cat /etc/openvpn/easy-rsa/pki/issued/$1.crt >> ~/$1-udp.ovpn
	cat /etc/openvpn/easy-rsa/pki/issued/$1.crt >> ~/$1-ssl.ovpn
	echo "</cert>" >> ~/$1-tcp.ovpn
	echo "</cert>" >> ~/$1-udp.ovpn
	echo "</cert>" >> ~/$1-ssl.ovpn
	echo "<key>" >> ~/$1-tcp.ovpn
	echo "<key>" >> ~/$1-udp.ovpn
	echo "<key>" >> ~/$1-ssl.ovpn
	cat /etc/openvpn/easy-rsa/pki/private/$1.key >> ~/$1-tcp.ovpn
	cat /etc/openvpn/easy-rsa/pki/private/$1.key >> ~/$1-udp.ovpn
	cat /etc/openvpn/easy-rsa/pki/private/$1.key >> ~/$1-ssl.ovpn
	echo "</key>" >> ~/$1-tcp.ovpn
	echo "</key>" >> ~/$1-udp.ovpn
	echo "</key>" >> ~/$1-ssl.ovpn
	echo "<tls-auth>" >> ~/$1-tcp.ovpn
	echo "<tls-auth>" >> ~/$1-udp.ovpn
	echo "<tls-auth>" >> ~/$1-ssl.ovpn
	cat /etc/openvpn/ta.key >> ~/$1-tcp.ovpn
	cat /etc/openvpn/ta.key >> ~/$1-udp.ovpn
	cat /etc/openvpn/ta.key >> ~/$1-ssl.ovpn
	echo "</tls-auth>" >> ~/$1-tcp.ovpn
	echo "</tls-auth>" >> ~/$1-udp.ovpn
	echo "</tls-auth>" >> ~/$1-ssl.ovpn
	}     
 

tail -n +2 /etc/openvpn/easy-rsa/pki/index.txt | grep "^V" | cut -d '=' -f 2 > /tmp/users  
if grep -Fxq "FlashSSH-$1" /tmp/users;then 
cat <<EOF > datemp  
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Este usuario ya existe</strong> </div>
EOF
cat  datemp;rm -rf datemp
else 
if (echo $name | egrep [^a-zA-Z0-9.-_] &> /dev/null);then
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Nombre de usuario no valido</strong>
</div>
EOF
cat  datemp;rm -rf datemp  
else 
if [[ -z $name ]];then 
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Nombre de usuario vacio</strong> </div> 
EOF
cat  datemp;rm -rf datemp  
else 
sizemin=$(echo ${#name}) 
if [[ $sizemin -lt 2 ]];then 
cat <<EOF > datemp  
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Nombre de usuario muy corto</strong> </div>
EOF
cat  datemp;rm -rf datemp  
else 
sizemax=$(echo ${#name}) 
if [[ $sizemax -gt 10 ]];then 
cat <<EOF > datemp  
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Nombre de usuario muy grande</strong> </div>
EOF
cat  datemp;rm -rf datemp  
else 
if [[ -z $pass ]];then
cat <<EOF > datemp  
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Contrase&ntilde;a vacia</strong> </div> 
EOF
cat  datemp;rm -rf datemp  
else 
sizepass=$(echo ${#pass}) 
if [[ $sizepass -lt 5 ]];then 
cat <<EOF > datemp  
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Contrase&ntilde;a muy corta</strong> </div>
EOF
cat  datemp;rm -rf datemp  
else 
if (echo $days | egrep '[^0-9]' &> /dev/null);then 
cat <<EOF > datemp  
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Numero de dias no valido</strong> </div>
EOF
cat  datemp;rm -rf datemp 
else 
if [[ -z $days ]];then 
cat <<EOF > datemp  
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Numero de dias vacios</strong> </div>
EOF
cat  datemp;rm -rf datemp 
else 
if [[ $days -lt 1 ]];then 
cat <<EOF > datemp  
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Numero de dias mayor que cero</strong> </div> 
EOF
cat  datemp;rm -rf datemp 
else  
valid=$(date '+%C%y-%m-%d' -d " +$days days") 
datespi=$(date "+%Y/%m/%d" -d " +$days days") 
useradd -M -s /bin/false FlashSSH-$1 -e $valid
(echo $pass; echo $pass)|passwd FlashSSH-$1 2>/dev/null 
IP=$(wget -qO- whatismyip.akamai.com) 
newclient FlashSSH-$1 $pass 
tput cuu1 && tput dl1 
cd 
sed -i "s;auth-user-pass;<auth-user-pass>\nFlashSSH-$1\n$pass\n</auth-user-pass>;g" ~/FlashSSH-$1-tcp.ovpn 
sed -i "s;auth-user-pass;<auth-user-pass>\nFlashSSH-$1\n$pass\n</auth-user-pass>;g" ~/FlashSSH-$1-udp.ovpn 
sed -i "s;auth-user-pass;<auth-user-pass>\nFlashSSH-$1\n$pass\n</auth-user-pass>;g" ~/FlashSSH-$1-ssl.ovpn 
zip FlashSSH-$1-config.zip FlashSSH-$1-tcp.ovpn FlashSSH-$1-udp.ovpn FlashSSH-$1-ssl.ovpn &> /dev/null  
[[ -e /var/www/html/ ]]&& mv FlashSSH-$1-config.zip /var/www/html/ 
rm -rf FlashSSH-$1-tcp.ovpn FlashSSH-$1-udp.ovpn FlashSSH-$1-ssl.ovpn 
echo "FlashSSH-$1 | $pass | $valid | http://$IP/FlashSSH-$1-config.zip" >> /etc/prokill/ovpn-reg 
dom=$(cat /etc/inset/dominio) 
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-success text-center p-2" style="font-size: 14px;">
<strong>¡CREADO CON EXITO!</strong> <hr><ul class="list-unstyled"> 
<li class="list-group-item d-flex justify-content-between align-items-center">Usuario <b>FlashSSH-$1</b></li>
<li class="list-group-item d-flex justify-content-between align-items-center">Contraseña <b>$pass</b></li> 
<li class="list-group-item d-flex justify-content-between align-items-center">Expira en <b>$datespi</b></li> 
<li class="list-group-item d-flex justify-content-between align-items-center">Puerto TCP & UDP <b>1194</b></li> 
<li class="list-group-item d-flex justify-content-between align-items-center">Puerto TLS/SSL <b>443</b></li>  
</ul> <a href="https://$dom/FlashSSH-$1-config.zip" download="FlashSSH-$1-config.zip">Descargar Configuracion</a> <br></br> 
<b>Disfrute usando nuestro servicio.</b> 
EOF
cat datemp; rm -rf datemp 
if [ "$pasg" = "si" ];then 
clear 
else 
echo "$ipaddres:$uid:$1" >> /etc/inset/dateipdays 
fi  
fi;fi;fi;fi;fi;fi;fi;fi;fi;fi