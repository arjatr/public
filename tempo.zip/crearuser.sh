#!/bin/bash  
name="$1" 
pass="$2" 
daysx="$3" 
ipaddres="$4" 
uid="$5" 

if [ "$daysx" = "three" ];then 
days="2" 
elif [ "$daysx" = "eight" ];then 
days="4" 
elif [ "$daysx" = "fifteen" ];then 
days="6" 
else 
days="1" 
fi 

[[ "$ipaddres" = "three" ]]&& exit 
[[ "$ipaddres" = "eight" ]]&& exit 
[[ "$ipaddres" = "fifteen" ]]&& exit 
[[ "$uid" = "" ]]&& exit  

domin=$(cat /etc/inset/dominio) 
limitereg=$(cat /etc/inset/limitereg) 
ipc=$(wget -qO- https://www.dropbox.com/s/vjzg8txm50npglq/Blacklist |grep "$ipaddres" |awk -F : {'print $1'})  
admin=$(wget -qO- https://www.dropbox.com/s/uk2yw1rxiza2b2t/admins |grep "$ipaddres" |awk -F : {'print $1'}) 
if [ $(awk -F : '$3 > 900 { print $1 }' /etc/passwd | grep -v "nobody" |grep -vi polkitd |grep -vi system-|wc -l) -gt "$limitereg" ]; then 
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Oops!</strong> SERVIDOR LLENO. </div>
EOF
cat  datemp;rm -rf datemp 
exit
fi 

if [ "$ipaddres" = "$ipc" ]; then 
cat <<EOF > datemp 
<div class="col-12 col-lg-4 mb-2">  
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Estas usando IP de FlashSSH usa otra ip para crear</strong> 
</div> 
EOF
cat  datemp;rm -rf datemp 
exit 
fi 

if [ "$admin" = "$ipaddres" ];then 
pasg="si" 
clear 
else 
pasg="no" 
touch /etc/inset/dateipdays 
if cat /etc/inset/dateipdays|awk -F : '{print $1}'|grep -w "$ipaddres" > /dev/null; then 
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Oops!</strong> SOLO UN USUARIO POR DIA. </div>
EOF
cat  datemp;rm -rf datemp 
exit 
fi 

if cat /etc/inset/dateipdays|awk -F : '{print $2}'|grep -w "$uid" > /dev/null; then 
cat <<EOF > datemp 
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Oops!</strong> SOLO UN USUARIO POR DIA. </div> 
EOF
cat  datemp;rm -rf datemp 
exit 
fi  
fi 
for us in $(cat /etc/inset/deling);do
teg=$(echo "$1" |grep -c $us|head -1) 
if [ "$teg" = "1" ]; then 
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Escribe un nombre normal</strong><br> 
<b>ELIJE EL QUE GENERA LA PAGINA POR DEFECTO</b> </div>
EOF
cat datemp;rm -rf datemp 
exit 
fi 
done 
awk -F : ' { print $1 }' /etc/passwd > /tmp/users  
if grep -Fxq "FlashSSH-$1" /tmp/users;then 
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Este usuario ya existe</strong> 
</div> 
EOF
cat  datemp;rm -rf datemp 
else 
if (echo $name | egrep [^a-zA-Z0-9.-_] &> /dev/null);then
cat <<EOF > datemp  
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Nombre de usuario no valido</strong>
</div>
EOF
cat  datemp;rm -rf datemp  
else 
if [[ -z $name ]];then 
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Nombre de usuario vacio</strong>
</div>
EOF
cat  datemp;rm -rf datemp
else 
sizemin=$(echo ${#name}) 
if [[ $sizemin -lt 2 ]];then 
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Nombre de usuario muy corto</strong>
</div>
EOF
cat  datemp;rm -rf datemp
else 
sizemax=$(echo ${#name}) 
if [[ $sizemax -gt 10 ]];then
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Nombre de usuario muy grande</strong> </div> 
EOF
cat datemp;rm -rf datemp  
else
if [[ -z $pass ]];then 
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Contrase&ntilde;a vacia</strong> </div> 
EOF
cat datemp;rm -rf datemp  
else 
sizepass=$(echo ${#pass}) 
if [[ $sizepass -lt 5 ]];then 
cat <<EOF > datemp  
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Contrase&ntilde;a muy corta</strong> </div>
EOF
cat  datemp;rm -rf datemp  
else 
if (echo $days | egrep '[^0-9]' &> /dev/null);then
cat <<EOF > datemp  
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Numero de dias no valido</strong> 
</div> 
EOF
cat  datemp;rm -rf datemp
else 
if [[ -z $days ]];then
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Numero de dias vacios</strong> </div> 
EOF
cat  datemp;rm -rf datemp 
else 
if [[ $days -lt 1 ]];then
cat <<EOF > datemp  
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Numero de dias mayor que cero</strong> </div>
EOF
cat  datemp;rm -rf datemp 
else  
valid=$(date '+%C%y-%m-%d' -d " +$days days") 
datespi=$(date "+%Y/%m/%d" -d " +$days days") 
name="FlashSSH-$1" 
keypub=$(cat /etc/prokill/dns/server.pub) 
ns=$(cat /etc/prokill/dns/ns)  
useradd -M -s /bin/false $name -e $valid 
(echo $pass; echo $pass)|passwd $name 2>/dev/null 
echo "$name | $pass | $datespi" >> /etc/prokill/database 
IPSEC=$(wget -qO- whatismyip.akamai.com) 
dom=$(cat /etc/inset/dominio) 
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-success text-center p-2" style="font-size: 14px;">
<strong>¡CREADO CON EXITO!</strong><hr><ul class="list-unstyled"> 
<li class="list-group-item d-flex justify-content-between align-items-center">Host <b>$dom</b></li>
<li class="list-group-item d-flex justify-content-between align-items-center">Ns <b>$ns</b></li> 
<li class="list-group-item d-flex justify-content-between align-items-center">Usuario <b>$name</b></li>
<li class="list-group-item d-flex justify-content-between align-items-center">Contraseña <b>$pass</b></li> 
<li class="list-group-item d-flex justify-content-between align-items-center">Public-key <b><button class="btn btn-sm btn-success py-0" data-clipboard-text="$keypub" data-original-title="" title="">Copiar key</button></b>
</li> <li class="list-group-item d-flex justify-content-between align-items-center">Expira en <b>$datespi</b></li>
</ul><b>Payload</b>
<script> 
function copy(){   
let ssClipboard = document.getElementById("ssClipboard");
ssClipboard.select();
document.execCommand("copy");
} 
</script> 
<textarea id="ssClipboard" class="form-control mb-2 font-italic" rows="3" style="font-size:0.8rem;overflow:hidden">GET / HTTP/1.1[crlf]Host: $dom[crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]</textarea> <br> <button class="d-block btn btn-sm btn-success btn-marketing btn-block rounded-pill" onclick="copy()">Copiar Payload</button>
<script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.4/clipboard.min.js"></script> 
<script>new ClipboardJS('.btn');</script>
EOF
cat datemp; rm -rf datemp
if [ "$pasg" = "si" ];then 
clear 
else 
echo "$ipaddres:$uid:$1" >> /etc/inset/dateipdays 
fi  

fi;fi;fi;fi;fi;fi;fi;fi;fi;fi