 #!/bin/bash 
nick="FlashSSH-$1" 
bugd="$2" 
daysx="$3" 
ipaddres="$4"
uid="$5"

[[ "$bugd" = "" ]]&& bugd="hostbug.com"  
if [ "$daysx" = "three" ];then
 diasuser="2" 
elif [ "$daysx" = "eight" ];then 
 diasuser="4" 
elif [ "$daysx" = "fifteen" ];then 
 diasuser="6"
 else 
 diasuser="1" 
 fi 

[[ "$ipaddres" = "three" ]]&& exit 
[[ "$ipaddres" = "eight" ]]&& exit 
[[ "$ipaddres" = "fifteen" ]]&& exit 
[[ "$uid" = "" ]]&& exit
domin=$(cat /etc/inset/dominio) 
limitereg=$(cat /etc/inset/limitev2)
ipc=$(wget -qO- https://www.dropbox.com/s/vjzg8txm50npglq/Blacklist |grep "$ipaddres" |awk -F : {'print $1'}) 
admin=$(wget -qO- https://www.dropbox.com/s/uk2yw1rxiza2b2t/admins |grep "$ipaddres" |awk -F : {'print $1'})
if [ $(cat /etc/prokill/RegV2ray|wc -l) -gt "$limitereg" ]; then
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Oops!</strong> SERVIDOR LLENO. </div>
EOF
cat  datemp;rm -rf datemp
exit 
fi
if [ "$ipaddres" = "$ipc" ]; then
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Estas usando IP de FlashSSH usa otra ip para crear</strong>
</div>
EOF
cat  datemp;rm -rf datemp
exit
fi

if [ "$admin" = "$ipaddres" ];then 
pasg="si" 
clear 
else 
pasg="no" 
touch /etc/inset/dateipdays 
if cat /etc/inset/dateipdays|awk -F : '{print $1}'|grep -w "$ipaddres" > /dev/null; then
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Oops!</strong> SOLO UN USUARIO POR DIA. </div>
EOF
cat  datemp;rm -rf datemp 
exit 
fi
if cat /etc/inset/dateipdays|awk -F : '{print $2}'|grep -w "$uid" > /dev/null; then
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Oops!</strong> SOLO UN USUARIO POR DIA. </div>
EOF
cat  datemp;rm -rf datemp 
exit
fi
fi
for us in $(cat /etc/inset/deling);do 
teg=$(echo "$1" |grep -c $us|head -1) 
if [ "$teg" = "1" ]; then
cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Escribe un nombre normal</strong><br> <b>Ejemplo: Mauro43</b> </div>
EOF
cat datemp;rm -rf datemp
exit 
fi 
done  
err_fun () {      
case $1 in
1) cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Null User</strong><br> </div>
EOF
cat  datemp;rm -rf datemp 
exit 
;; 
2) cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Very short name (MIN: 2 CHARACTERS)</strong><br> </div>
EOF
cat  datemp;rm -rf datemp 
exit 
;; 
3) cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Nombre muy grande (MAX: 5 CHARACTERS)</strong><br></div>
EOF
cat  datemp;rm -rf datemp 
exit 
;; 
4) cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Contraseña nula</strong><br> </div>
EOF
cat  datemp;rm -rf datemp 
exit 
;; 
5) cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Contraseña muy corta </strong><br></div>
EOF
cat  datemp;rm -rf datemp
exit 
;; 
6) cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Contraseña muy grande </strong><br> </div>
EOF
cat  datemp;rm -rf datemp
exit 
;; 
7) cat <<EOF > datemp  
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Duración nula </strong><br> </div>
EOF
cat  datemp;rm -rf datemp
exit 
;; 
8) cat <<EOF > datemp 
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Números de uso de duración no válidos </strong><br> </div>
EOF
cat  datemp;rm -rf datemp
exit 
;; 
9) cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">Duración máxima y un año</strong><br> </div> 
EOF
cat  datemp;rm -rf datemp 
exit 
;; 
11) cat <<EOF > datemp
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Límite nulo</strong><br> </div>
EOF
cat  datemp;rm -rf datemp 
exit 
;; 
12) cat <<EOF > datemp  
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Números de uso de límite no válidos</strong><br> </div>
EOF
cat  datemp;rm -rf datemp
exit 
;; 
14) cat <<EOF > datemp  
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">EL usuario ya existe</strong><br> </div>
EOF
cat  datemp;rm -rf datemp
exit 
;; 
16) cat <<EOF > datemp 
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; ">
<strong class="text-capitalize">(Sólo números)</strong><br> </div>
EOF
cat  datemp;rm -rf datemp 
exit 
;; 
17) cat <<EOF > datemp  
<div class="col-12 col-lg-4 mb-2"> 
<div class="alert alert-card alert-danger" role="alert" style=" padding-left: 42px; "> 
<strong class="text-capitalize">Sin Informacion</strong><br> </div> 
EOF
cat  datemp;rm -rf datemp 
exit 
;; 
esac 
}   
valid=$(date '+%C%y-%m-%d' -d " +31 days") 
UUID=`uuidgen`
bs=$(sed -n '/'"clients"'/=' /etc/v2ray/config.json)
nu1=$(echo $bs + 1 | bc)       
nick="$(echo $nick|sed -e 's/[^a-z0-9 -]//ig')" 
chuser=$(cat /etc/prokill/RegV2ray|grep -w "$nick" |awk  '{print $3}')
if [ "$nick" = "$chuser" ]; then
err_fun 14 && continue 
fi
if [[ -z $nick ]]; then     
err_fun 17 && continue       
elif [[ "${#nick}" -lt "2" ]]; then      
err_fun 2 && continue      
elif [[ "${#nick}" -gt "22" ]]; then      
err_fun 3 && continue      
fi      
if [[ -z "$diasuser" ]]; then      
err_fun 17 && continue      
elif [[ "$diasuser" != +([0-9]) ]]; then      
err_fun 8 && continue      
elif [[ "$diasuser" -gt "360" ]]; then      
err_fun 9 && continue      
fi    
portf=$(cat /etc/v2ray/config.json |grep -w "port"|awk -F : '{print $2}'|sed 's;,;;g'|tr -d '[[:space:]]') 
domain=$(cat /etc/v2ray/config.json |grep -w "host"|awk -F : '{print $2}'|sed 's;";;g') 
path=$(cat /etc/v2ray/config.json |grep -w "path"|awk -F : '{print $2}'|sed 's;";;g') 
alertv2=$(cat /etc/v2ray/config.json |grep -w "alterId"|awk -F : 'NR==1{print $3}'|sed 's;, "level";;g') 
sed -i "$nu1 i\           \ { "'"'"id"'"'": "'"'"$UUID"'"'", "'"'"alterId"'"'":$alertv2, "'"'"level"'"'":1 }, " /etc/v2ray/config.json 
valid=$(date '+%C%y-%m-%d' -d " +$diasuser days") && datexp=$(date "+%F" -d " + $diasuser days") 
echo "$UUID | $nick | $valid" >> /etc/prokill/RegV2ray 
screen -r -S "v2ser" -X quit >/dev/null 2>&1 
screen -wipe > /dev/null 2>&1 
screen -dmS v2ser v2raypro -config /etc/v2ray/config.json >/dev/null 2>&1 
vmes=$(echo '{"add":"'$bugd'","aid":"'$alertv2'","id":"'$UUID'","host":"'$domain'","net":"ws","path":"'$path'","port":"'$portf'","ps":"'$domain'","tls":"","type":"none","v":"2"}'|base64|xargs|tr -d '[[:space:]]') 
cat <<EOF > datev2 
<div class="col-12 col-lg-4 mb-2">
<div class="alert alert-success text-center p-2" style="font-size: 14px;"> 
<strong>¡CREADO CON EXITO!</strong><hr><ul class="list-unstyled"> 
<li class="list-group-item justify-content-between align-items-center p-1">Hostname (Cloudflare): <br><b>$domain</b></li> 
<li class="list-group-item justify-content-between align-items-center p-1">UUID: <br><b>$UUID</b></li> 
<li class="list-group-item d-flex justify-content-between align-items-center">Remarks: <b>$nick</b></li> 
<li class="list-group-item d-flex justify-content-between align-items-center">Path: <b>$path</b></li> 
<li class="list-group-item d-flex justify-content-between align-items-center">AlterId: <b>$alertv2</b></li> 
<li class="list-group-item d-flex justify-content-between align-items-center">Network: <b>ws</b></li> 
<li class="list-group-item d-flex justify-content-between align-items-center">Port: <b>$portf</b></li> 
<li class="list-group-item d-flex justify-content-between align-items-center">Expira: <b>$valid</b></li> 
</ul> <button class="btn btn-white btn-marketing rounded-pill btn-block" data-clipboard-text="vmess://${vmes}" data-original-title="" title=""><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-copy mr-2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>Copiar Config</button> </div><div class="card">
<script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.4/clipboard.min.js"></script> 
<script>new ClipboardJS('.btn');</script> 
EOF
cat datev2;rm -rf datev2
if [ "$pasg" = "si" ];then
clear 
else 
echo "$ipaddres:$uid:$1" >> /etc/inset/dateipdays 
fi 